# Sistema de Comissões
Sistema web para controle de comissões, oportunidades, pagamentos e despesas.

## Funcionalidades
- CRUD completo de Oportunidades
- CRUD de Pagamentos com geração automática de parcelas
- CRUD de Despesas e Outras Receitas
- Dashboard com gráficos e resumos
- Dark Mode
- Integração com Google Sheets via API
