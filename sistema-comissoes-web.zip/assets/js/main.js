// JS será colocado na próxima célula por ser muito extenso e modularizado.
